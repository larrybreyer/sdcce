# 2024-01-SP-MAD
 Spring 2024 Mobile Apps Dev project

Plain Old JavaScript + Cordova + Monaca + Onsen UI + PouchDB
