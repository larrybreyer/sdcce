import React from 'react'

export default class EmployeeFilter extends React.Component {
	render() {
		return (
			<div>This is a placeholder for the employee filter.</div>
		)
	}
}