import React from 'react'
import { Card } from 'react-bootstrap'

export default function EmployeeReport() {
    return (
        <Card>
            <Card.Header as="h5">Filter</Card.Header>
            <Card.Body>
                <Card.Text>
                    This is a placeholder for employee reports.
                </Card.Text>
            </Card.Body>
        </Card>
    )
}