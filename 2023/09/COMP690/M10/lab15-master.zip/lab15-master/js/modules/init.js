const init = () => {
    // CREATE AN ARRAY OF EMPLOYEES
    let data = [
        [23424665, "Amal Shookup", 2344, "amal@vectacorp.com", "Administrative"],
        [12341244, "Holly Unlikely", 5352, "holly@vectacorp.com", "Sales"],
        [14545423, "Robin Banks", 7867, "robin@vectacorp.com", "Marketing"],
        [13413453, "Cody Pendant", 1235, "cody@vectacorp.com", "Sales"],
        [11111111, "Evan Elpus", 5433, "evan@vectacorp.com", "Sales"],
        [22222222, "Haywood Jabuzoff", 5421, "haywood@vectacorp.com", "Engineering"],
        [33333333, "Ginger Vitis", 7654, "ginger@vectacorp.com", "Marketing"],
        [44444444, "Lois Bidder", 7890, "lois@vectacorp.com", "Executive"],
        [55555555, "Aaron Tyres", 5674, "aaron@vectacorp.com", "Administrative"],
        [66666666, "Xavier Breath", 4367, "xavier@vectacorp.com", "Administrative"],
        [77777777, "Justin Case", 1111, "justin@vectacorp.com", "Engineering"],
        [88888888, "Stu Pedasso", 3565, "stu@vectacorp.com", "Sales"],
        [99999999, "Juan Nightstand", 2555, "juan@vectacorp.com", "Executive"],
        [11112222, "Ilene Dover", 4050, "ilene@vectacorp.com", "Administrative"],
        [11113333, "Hadley Newham", 4995, "hadley@vectacorp.com", "Engineering"],
        [11114444, "Eureka Garlic", 4367, "eureka@vectacorp.com", "Administrative"],
        [11115555, "Hugo First", 1224, "hugo@vectacorp.com", "QA"],
        [11116666, "Jillian Here", 8867, "jullian@vectacorp.com", "QA"],
        [22227777, "Gladys Overwith", 4367, "gladys@vectacorp.com", "Marketing"]
    ]
    return data
}

export { init }