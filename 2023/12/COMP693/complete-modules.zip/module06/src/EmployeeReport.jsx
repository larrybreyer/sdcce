import React from 'react'

export default function EmployeeReport() {
    return (
        <div>
            <h1>This is a placeholder for the employee report.</h1>
        </div>
    )
}